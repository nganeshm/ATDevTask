package com.Student.Data.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class StudentEntity {


private int Srollno;
private String Sname;



public StudentEntity(int srollno, String sname) {
	super();
	Srollno = srollno;
	Sname = sname;
}

public StudentEntity() {
	super();
	// TODO Auto-generated constructor stub
}
@Id
public int getSrollno() {
	return Srollno;
}
public void setSrollno(int srollno) {
	Srollno = srollno;
}
public String getSname() {
	return Sname;
}
public void setSname(String sname) {
	Sname = sname;
}

@Override
public String toString() {
	return "StudentEntity [Srollno=" + Srollno + ", Sname=" + Sname + "]";
}


}
