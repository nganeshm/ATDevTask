package com.Student.Data.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Student.Data.DAO.StudentDao;
import com.Student.Data.Entity.StudentEntity;

@Service

public class StudentService {

	@Autowired
	StudentDao sd;
	
	//Get
	public StudentEntity getstudentbyrollnum(int Srollno) {
		return sd.getstudentbyRollnum(Srollno);
		
	}
	
	//Post
	public String insertnewstudent(StudentEntity st) {
		return sd.insertstudent(st);
	}
	
	//Delete
	public String deletestudentbyrollnum(int Srollno) {
		return sd.deletestudentbyrollnum(Srollno);
	}
	
	//Update
	public String updatestudentbyrollnum(int Srollno) {
	    return sd.updatestudentbyrollnu(Srollno);
	}
	
}
