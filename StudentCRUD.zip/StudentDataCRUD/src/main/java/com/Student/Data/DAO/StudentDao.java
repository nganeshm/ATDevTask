package com.Student.Data.DAO;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Student.Data.Entity.StudentEntity;
@Repository
public class StudentDao {
    @Autowired
	SessionFactory sf;
	
    
  
    
    // @Get(Select) Student By Roll Number.
    public StudentEntity getstudentbyRollnum(int Srollno) {
    Session ss=sf.openSession();
    Transaction tr=ss.beginTransaction();
    StudentEntity Sname=ss.get(StudentEntity.class,Srollno);
    tr.commit();
    ss.close();
    return Sname;	
	}
    
    // @Post(Insert) New Student By Roll Number.
    public String insertstudent(StudentEntity id) {
    	Session ss=sf.openSession();
    	Transaction tr=ss.beginTransaction();
    	ss.save(id);
    	tr.commit();
    	ss.close();
    	return "Done..New Student Inserted !";
    }
    
    // @Delete(delete) the Student by Roll Number.
    public String deletestudentbyrollnum(int Srollno){
    	Session ss=sf.openSession();
    	Transaction tr=ss.beginTransaction();
    	StudentEntity st=ss.get(StudentEntity.class,Srollno);
    	ss.delete(st);
    	tr.commit();
    	ss.close();
    	return "Deleted referenced Data";
    }
    
    // Put(Update) the student data by roll number.
    public String updatestudentbyrollnu(int Srollno) {
    	Session ss=sf.openSession();
    	Transaction tr=ss.beginTransaction();
    	StudentEntity st=ss.get(StudentEntity.class,Srollno);
    	ss.update(st);
    	tr.commit();
    	ss.close();
    	return "Student Data Updated";
    }
    
    
    
    
    
}
